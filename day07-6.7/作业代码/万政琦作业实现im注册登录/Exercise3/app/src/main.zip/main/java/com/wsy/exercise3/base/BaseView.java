package com.wsy.exercise3.base;

public interface BaseView {
    void showToast(String msg);
}
